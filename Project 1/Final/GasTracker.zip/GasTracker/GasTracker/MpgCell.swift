//
//  MpgCell.swift
//  GasTracker
//
//  Created by Jacob Brauchler on 2/28/17.
//  Copyright © 2017 JBrauchler. All rights reserved.
//

import UIKit

class MpgCell: UITableViewCell {
    
    @IBOutlet weak var mpgLabel: UILabel!
    @IBOutlet weak var vehicleLabel: UILabel!
    @IBOutlet weak var gasStationLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!


    
}
