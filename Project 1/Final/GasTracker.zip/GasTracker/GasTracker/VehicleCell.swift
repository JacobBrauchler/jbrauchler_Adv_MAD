//
//  VehicleCell.swift
//  GasTracker
//
//  Created by Jacob Brauchler on 2/28/17.
//  Copyright © 2017 JBrauchler. All rights reserved.
//

import UIKit

class VehicleCell: UITableViewCell {
    
    @IBOutlet weak var makeLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    
}
